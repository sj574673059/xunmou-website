const header = document.querySelector('[data-header]')
const menuToggle = document.querySelector('[data-menu-toggle]')
const mobileNav = document.querySelector('[data-mobile-nav]')
const backTop = document.querySelector('[data-back-top]')

function updateHeader() {
  if (!header) return
  header.classList.toggle('is-scrolled', window.scrollY > 24)
  if (backTop) backTop.classList.toggle('is-visible', window.scrollY > 640)
}

updateHeader()
window.addEventListener('scroll', updateHeader, { passive: true })

menuToggle?.addEventListener('click', () => {
  const open = menuToggle.getAttribute('aria-expanded') !== 'true'
  menuToggle.setAttribute('aria-expanded', String(open))
  menuToggle.setAttribute('aria-label', open ? '关闭导航' : '打开导航')
  header?.classList.toggle('menu-open', open)
  document.body.classList.toggle('nav-open', open)
})

mobileNav?.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    header?.classList.remove('menu-open')
    document.body.classList.remove('nav-open')
    menuToggle?.setAttribute('aria-expanded', 'false')
  })
})

backTop?.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' })
})

document.querySelectorAll('.solution-trigger').forEach((trigger) => {
  trigger.addEventListener('click', () => {
    const item = trigger.closest('.solution-item')
    const open = item?.classList.contains('is-open')
    document.querySelectorAll('.solution-item').forEach((node) => {
      node.classList.remove('is-open')
      node.querySelector('.solution-trigger')?.setAttribute('aria-expanded', 'false')
    })
    if (!open && item) {
      item.classList.add('is-open')
      trigger.setAttribute('aria-expanded', 'true')
    }
  })
})

const revealItems = document.querySelectorAll('[data-reveal]')
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible')
          observer.unobserve(entry.target)
        }
      })
    },
    { threshold: 0.08, rootMargin: '0px 0px -32px' }
  )
  revealItems.forEach((item) => observer.observe(item))
} else {
  revealItems.forEach((item) => item.classList.add('is-visible'))
}

const form = document.querySelector('[data-contact-form]')
if (form) {
  const email = form.getAttribute('data-email') || ''
  const button = form.querySelector('button[type="submit"]')
  const hint = form.querySelector('[data-form-hint]')
  if (!email && button) button.disabled = true
  if (!email && hint) hint.textContent = '业务邮箱配置完成后，此表单即可直接调用邮件客户端发送。'

  form.addEventListener('submit', (event) => {
    event.preventDefault()
    if (!email) return
    const data = new FormData(form)
    const name = String(data.get('name') || '未填写称呼')
    const contact = String(data.get('contact') || '未填写')
    const topic = String(data.get('topic') || '业务咨询')
    const message = String(data.get('message') || '')
    const subject = `网站业务咨询｜${topic}｜${name}`
    const body = [
      `称呼：${name}`,
      `联系方式：${contact}`,
      `合作方向：${topic}`,
      '',
      '需求说明：',
      message
    ].join('\n')
    window.location.href = `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  })
}

const hashTarget = window.location.hash ? document.querySelector(window.location.hash) : null
if (hashTarget) {
  setTimeout(() => hashTarget.scrollIntoView({ block: 'start' }), 120)
}
